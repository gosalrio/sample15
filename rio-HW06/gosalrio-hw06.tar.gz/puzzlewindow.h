#ifndef PUZZLEWINDOW_H
#define PUZZLEWINDOW_H

#include <QMainWindow>

class PuzzleWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit PuzzleWindow(QMainWindow *parent = 0);

private slots:

};

#endif // PUZZLEWINDOW_H
